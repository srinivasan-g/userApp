export const STORE_MOCK = { items: [{ id: 3, name: 'anitha', isValid: false }, { id: 4, name: 'kaushik', isValid: false }] }
export const EDIT_STORE_MOCK = { items: [{ id: 3, name: 'anitha', isValid: false }, { id: 4, name: 'kaushik', isValid: true }] }
