export const API_MOCK = [
    { "name": "Anitha", "id": 1 },
    { "name": "kaushik", "id": 2 },
    { "name": "srini", "id": 3 },
    { "name": "daksha", "id": 4 }
  ]